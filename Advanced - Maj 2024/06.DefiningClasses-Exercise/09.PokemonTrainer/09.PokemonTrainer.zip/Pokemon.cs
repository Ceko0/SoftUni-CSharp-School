﻿namespace _09.PokemonTrainer
{
    internal class Pokemon
    {
        public string  Name { get; set; }       
        public string Element { get; set; }
        public int Healt { get; set; }


    }
}
