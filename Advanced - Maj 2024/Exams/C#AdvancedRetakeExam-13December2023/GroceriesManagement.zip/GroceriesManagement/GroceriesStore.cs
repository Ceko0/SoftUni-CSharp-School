﻿namespace GroceriesManagement
{
    public class GroceriesStore
    {
    }
}
