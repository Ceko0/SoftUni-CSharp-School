﻿namespace GroceriesManagement
{
    public class Product
    {
    }
}
