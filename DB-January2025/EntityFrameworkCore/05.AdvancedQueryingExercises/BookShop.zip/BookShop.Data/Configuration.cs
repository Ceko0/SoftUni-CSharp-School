﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-4KOOIQJ;Database=BookShop;Integrated Security=True;";
    }
}
