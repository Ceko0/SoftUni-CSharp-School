﻿namespace MusicHub.Data.Configuration
{
    public static class ConnectionConfiguration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-4KOOIQJ;Database=ElProApp;Trusted_Connection=True;TrustServerCertificate=True;";
    }
}
