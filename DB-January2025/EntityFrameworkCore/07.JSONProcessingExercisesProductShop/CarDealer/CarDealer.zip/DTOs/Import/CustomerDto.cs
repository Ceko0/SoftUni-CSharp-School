﻿namespace CarDealer.DTOs.Import
{
    public class CustomerDto
    {
        public string Name { get; set; }
        public string BirthDate { get; set; }
        public bool IsYoungDriver { get; set; }
    }
}
