﻿namespace CarDealer.DTOs.Import
{
    public class SaleDto
    {
        public int CarId { get; set; }
        public int CustomerId { get; set; }
        public string Discount { get; set; }
    }
}
