﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-4KOOIQJ;Database=ProductShop;Integrated Security=True";
    }
}
