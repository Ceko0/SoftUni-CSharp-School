﻿namespace Breakout.Enums
{
    public enum Direction
    {
        Left,
        Right
    }
}
