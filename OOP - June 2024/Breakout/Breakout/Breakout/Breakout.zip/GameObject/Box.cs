﻿namespace Breakout.GameObject
{
    public class Box
    {
        private readonly Wall wall;
        private readonly char foodSymbol;
        private const char BoxSymbol = '\u25A0';
        public int LeftX;
        public int startingRow;
        public int numberOfColl;
        public  Box(Wall wall, int startingRow,int numberOfColl)
        {
            LeftX = wall.LeftX;
            this.wall = wall;
            this.startingRow = startingRow;
            this.numberOfColl = numberOfColl;
            DrawBoxField(this.startingRow, this.numberOfColl);
        }
        public void DrawBoxField(int startingRow , int numberOfColl)
        {
            for (int i = 1; i <= numberOfColl; i++)
            {
                for (int leftX = 1; leftX < LeftX - 1; leftX++)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(leftX, startingRow);
                    Console.Write(BoxSymbol);
                    Console.ResetColor();
                }

                startingRow++;
            }
        }
    }
}
