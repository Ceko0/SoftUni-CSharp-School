﻿using Breakout.Enums;
using System;
using System.Linq;
using System.Threading;

namespace Breakout.GameObject
{
    public class Engine
    {
        private readonly Point[] pointsOfDirection;
        private readonly Wall wall;
        private double sleepTime;
        private Direction direction;
        private Board board;
        private Ball ball;

        public Engine(Wall wall)
        {
            this.wall = wall;
            this.sleepTime = 100;
            this.pointsOfDirection = new Point[2];
            CreateDirections();
            board = new Board(wall.LeftX / 2 - 2, wall.TopY - 3, wall);
            ball = new Ball(wall.LeftX / 2, wall.TopY / 2, 1, 1, 0, wall.LeftX, 0, wall.TopY); // Initialize the ball
        }

        public void Run()
        {
            while (true)
            {
                if (Console.KeyAvailable)
                {
                    GetNextDirection();
                    board.MoveBoard(pointsOfDirection[(int)direction]);
                    Point point;
                    if (0 == (int)direction)
                        point = new Point(board.boardPosition.Last().LeftX + 1, board.boardPosition.Last().TopY);
                    else
                        point = new Point(board.boardPosition.First().LeftX - 1, board.boardPosition.First().TopY);

                    Console.BackgroundColor = ConsoleColor.White;
                    point.Draw(point.LeftX, point.TopY, ' ');
                }

                ball.Move(); // Move the ball
                ball.CheckCollisionWithBoard(board); // Check collision with the board

                sleepTime -= 0.01;
                Thread.Sleep((int)sleepTime);
            }
        }

        private void AskUserForRestart()
        {
            int leftX = wall.LeftX + 1;
            int topY = 3;
            Console.SetCursorPosition(leftX, topY);
            Console.Write("Would you like to continue? y/n");

            string input = Console.ReadLine().ToLower();

            if (input == "y")
            {
                Console.Clear();
                StartUp.Main();
            }
            else
            {
                StopGame();
            }
        }

        private void StopGame()
        {
            Console.SetCursorPosition(20, 10);
            Console.WriteLine("Game over!");
            Environment.Exit(0);
        }

        private void CreateDirections()
        {
            pointsOfDirection[0] = new Point(-1, 0);
            pointsOfDirection[1] = new Point(1, 0);
        }

        private void GetNextDirection()
        {
            ConsoleKeyInfo userInput = Console.ReadKey();

            if (ConsoleKey.LeftArrow == userInput.Key)
                direction = Direction.Left;
            else if (ConsoleKey.RightArrow == userInput.Key)
                direction = Direction.Right;

            Console.CursorVisible = false;
        }
    }
}
