﻿namespace Breakout.GameObject
{
    public class Ball
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public int SpeedX { get; private set; }
        public int SpeedY { get; private set; }
        private int MinX { get; set; }
        private int MaxX { get; set; }
        private int MinY { get; set; }
        private int MaxY { get; set; }

        public Ball(int startX, int startY, int speedX, int speedY, int minX, int maxX, int minY, int maxY)
        {
            X = startX;
            Y = startY;
            SpeedX = speedX;
            SpeedY = speedY;
            MinX = minX;
            MaxX = maxX;
            MinY = minY;
            MaxY = maxY;
        }

        public void Move()
        {
            Clear();

            X += SpeedX;
            Y += SpeedY;

            // Check for collision with walls
            if (X <= MinX || X >= MaxX)
            {
                SpeedX = -SpeedX;
            }

            if (Y <= MinY || Y >= MaxY)
            {
                SpeedY = -SpeedY;
            }

            Draw();
        }

        public void Draw()
        {
            Console.SetCursorPosition(X, Y);
            Console.Write("O");
        }

        public void Clear()
        {
            Console.SetCursorPosition(X, Y);
            Console.Write(" ");
        }

        public bool CheckCollisionWithBoard(Board board)
        {
            foreach (var point in board.boardPosition)
            {
                if (X == point.LeftX && Y == point.TopY)
                {
                    SpeedY = -SpeedY; // Reflect the ball
                    return true;
                }
            }
            return false;
        }
    }
}