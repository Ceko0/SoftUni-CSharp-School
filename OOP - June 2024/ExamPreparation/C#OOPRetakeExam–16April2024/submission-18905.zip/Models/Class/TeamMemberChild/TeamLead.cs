﻿using TheContentDepartment.Enums;

namespace TheContentDepartment.Models.Class.TeamMemberChild
{
    public class TeamLead : TeamMember
    {
        public TeamLead(string name, string path) 
            : base(name, path)
        {
            if (!TeamLeadPath.TryParse(path, out TeamLeadPath pathResult)) throw new ArgumentException($"{nameof(path)} path is not valid.");
        }

        public override string ToString()
        {
            return $"{Name} ({GetType().Name}) – Currently working on {InProgress.Count} tasks.";
        }
    }
}
