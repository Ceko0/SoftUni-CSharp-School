﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheContentDepartment.Enums;

namespace TheContentDepartment.Models.Class.TeamMemberChild
{
    public class ContentMember : TeamMember
    {
        public ContentMember(string name, string path) 
            : base(name, path)
        {
            if (!ContentMemberPath.TryParse(path, out ContentMemberPath pathResult)) 
                throw new ArgumentException($"{nameof(path)} path is not valid.");

        }

        public override string ToString()
        {
            return $"{Name} - {Path} path. Currently working on {InProgress.Count} tasks.";

        }
    }
}
