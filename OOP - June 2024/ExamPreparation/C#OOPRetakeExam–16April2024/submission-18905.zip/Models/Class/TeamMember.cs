﻿using TheContentDepartment.Enums;
using TheContentDepartment.Models.Contracts;

namespace TheContentDepartment.Models.Class
{
    public abstract class TeamMember : ITeamMember
    {
        private List<string> inProgress;
        public TeamMember(string name, string path)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name cannot be null or whitespace.");
            Name = name;
            Path = path;
            inProgress = new();
            InProgress = inProgress.AsReadOnly();
        }

        public string Name { get; }
        public string Path { get; }
        public IReadOnlyCollection<string> InProgress { get; }
        public void WorkOnTask(string resourceName)
        {
            inProgress.Add(resourceName);
        }

        public void FinishTask(string resourceName)
        {
            inProgress.Remove(resourceName);
        }
    }
}
