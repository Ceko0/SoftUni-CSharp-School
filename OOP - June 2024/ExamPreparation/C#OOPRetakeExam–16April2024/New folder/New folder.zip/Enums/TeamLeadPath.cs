﻿namespace TheContentDepartment.Enums
{
    public enum TeamLeadPath
    {
        Master
    }
}
