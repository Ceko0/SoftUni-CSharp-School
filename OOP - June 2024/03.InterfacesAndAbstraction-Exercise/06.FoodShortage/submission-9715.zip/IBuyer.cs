﻿namespace FoodShortage
{
    public interface IBuyer
    {
        public int Food { get; }
        public void BuyFood();
    }
}
