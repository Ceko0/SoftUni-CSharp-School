﻿namespace BorderControl
{
    public interface IBirthdatable
    {
        public string Birthdate { get; }
    }
}
