﻿namespace Interfaces.SoldierInterfece.PrivateInterfece
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get; }
    }
}