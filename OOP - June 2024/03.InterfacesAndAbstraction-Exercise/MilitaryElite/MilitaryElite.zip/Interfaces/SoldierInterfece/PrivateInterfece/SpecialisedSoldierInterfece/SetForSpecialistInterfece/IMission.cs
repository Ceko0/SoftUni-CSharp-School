﻿namespace MilitaryElite.Interfaces.SoldierInterfece.PrivateInterfece.SpecialisedSoldierInterfece.SetForSpecialistInterfece
{
    public interface IMission
    {

    }
}
