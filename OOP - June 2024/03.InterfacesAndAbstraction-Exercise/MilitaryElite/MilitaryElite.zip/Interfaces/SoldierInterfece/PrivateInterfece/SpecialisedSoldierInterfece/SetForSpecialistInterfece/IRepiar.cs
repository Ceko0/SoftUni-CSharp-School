﻿namespace MilitaryElite.Interfaces.SoldierInterfece.PrivateInterfece.SpecialisedSoldierInterfece.SetForSpecialistInterfece
{
    public interface IRepiar
    {
        string PartName { get; }
        int WorkedHours { get; }
    }
}
