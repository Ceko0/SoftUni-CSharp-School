﻿namespace MilitaryElite.Enums
{
    public enum SoldierCorps
    {
        Airforces,
        Marines
    }
}