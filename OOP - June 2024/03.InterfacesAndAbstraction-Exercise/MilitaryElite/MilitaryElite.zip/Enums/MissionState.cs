﻿namespace MilitaryElite.Enums
{
    public enum MissionState
    {
        InProgress,
        Finished
    }
}
