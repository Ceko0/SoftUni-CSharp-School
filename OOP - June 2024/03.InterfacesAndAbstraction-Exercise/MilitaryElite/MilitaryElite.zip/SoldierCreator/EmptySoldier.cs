﻿namespace MilitaryElite.SoldierCreator
{
    public class EmptySoldier : ISoldierCreator
    {

    }
}
