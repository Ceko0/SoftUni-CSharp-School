﻿namespace _08.CollectionHierarchy.Interfeces
{
    public interface IAdd
    {
        public int Add(string item);
    }
}
