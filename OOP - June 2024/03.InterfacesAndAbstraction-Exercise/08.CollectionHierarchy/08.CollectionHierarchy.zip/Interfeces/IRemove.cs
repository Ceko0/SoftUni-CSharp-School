﻿namespace _08.CollectionHierarchy.Interfeces
{
    public interface IRemove
    {
        public string Remove();
    }
}
