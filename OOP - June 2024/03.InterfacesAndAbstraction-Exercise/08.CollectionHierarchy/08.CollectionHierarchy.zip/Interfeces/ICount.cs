﻿namespace _08.CollectionHierarchy.Interfeces
{
    public interface ICount
    {
        public int Count { get; }
    }
}
