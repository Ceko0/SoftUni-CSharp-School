﻿namespace Telephony
{
    public interface IBrowsable
    {
        public abstract string Browse(string url);
    }
}
