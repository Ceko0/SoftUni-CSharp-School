﻿namespace Telephony
{
    public interface ICalleble
    {
        public abstract string Call(string number);
    }
}
