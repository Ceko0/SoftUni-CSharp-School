﻿namespace Shapes
{
    public interface IDrawing
    {
        public string Draw();
    }
}
