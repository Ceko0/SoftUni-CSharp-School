﻿namespace WildFarm.ClassCreator
{
    public class AnimalCreator : IAnimalCreator
    {
    }
}
