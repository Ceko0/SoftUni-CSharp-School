﻿namespace WildFarm.ClassCreator
{
    public class FoodCreator : IFoodCreator
    {
    }
}
