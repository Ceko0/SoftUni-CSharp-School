﻿namespace WildFarm.Interfeces
{
    public interface IProductSound
    {
        public abstract string ProductSound();
    }
}
