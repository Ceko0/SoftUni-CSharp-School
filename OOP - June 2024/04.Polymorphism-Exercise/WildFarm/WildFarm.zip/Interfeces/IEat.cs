﻿using WildFarm.Models.FoodTree;

namespace WildFarm.Interfeces
{
    public interface IEat
    {
        public abstract void Eat(Food food);
        
    }
}
