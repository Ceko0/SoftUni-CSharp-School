﻿namespace WildFarm.Models.FoodTree
{
    public class Fruit : Food
    {
        public Fruit(string name, int quantity)
           : base(name, quantity)
        {
        }
    }
}
