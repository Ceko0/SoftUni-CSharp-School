﻿namespace WildFarm.Models.FoodTree
{
    public class Vegetable : Food
    {
        public Vegetable(string name, int quantity) 
            : base(name, quantity)
        {
        }
    }
}
