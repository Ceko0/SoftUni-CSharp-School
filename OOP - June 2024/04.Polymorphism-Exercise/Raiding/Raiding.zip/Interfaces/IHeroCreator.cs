﻿namespace Raiding.Interfaces
{
    public interface IHeroCreator
    {
        IHero Create(string name);
    }
}
