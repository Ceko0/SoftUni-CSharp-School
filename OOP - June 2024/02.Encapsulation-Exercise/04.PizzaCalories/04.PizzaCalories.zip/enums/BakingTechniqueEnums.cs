﻿namespace PizzaCalories.enums
{
    public enum BakingTechniqueEnums
    {
        crispy,
        chewy,
        homemade
    }
}
