﻿namespace PizzaCalories.enums
{
    public enum ToppingTypeEnums
    {
        meat, 
        veggies, 
        cheese, 
        sauce
    }
}
