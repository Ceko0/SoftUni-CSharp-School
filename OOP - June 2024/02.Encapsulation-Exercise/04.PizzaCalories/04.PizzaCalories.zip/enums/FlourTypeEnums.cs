﻿namespace PizzaCalories.enums
{
    public enum FlourTypeEnums
    {
        white,
        wholegrain
    }
}
