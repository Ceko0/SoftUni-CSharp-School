using System;
using NUnit.Framework;

namespace Championship.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestAddTeam_Success()
        {
            Assert.Pass();
        }
    }
}